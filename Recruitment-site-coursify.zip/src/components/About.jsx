// src/components/About.js
import React from 'react';

const About = () => {
  return (
    <div className='About'>
      <br></br>
      <h2>About Us</h2>
      <br></br>
      <p>
        Welcome to our recruitment site! We connect employers with talented interns, providing a platform for finding the best internships and job opportunities.
      </p>
      <p>
        Our mission is to bridge the gap between employers and students, making it easier for both to find the perfect fit.
      </p>
     
    </div>
  );
};

export default About;

// src/components/PostInternship.js
import React from 'react';
import HomePage from './HomePage';
import { useState } from 'react';

const postConfirm=false;

const PostInternship = (props) => {
  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission logic here
//     {!props.name ? alert("Login Please") : (confirm("Want to Submit Internship?") ?
// (<HomePage />):(console.log("NOT SURE!"))

  };

  return (
    <div>
      <h2>Post an Internship</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="title">Title:</label>
        <input type="text" id="title" name="title" required />

        <label htmlFor="stipend">Stipend:</label>
        <input type="text" id="stipend" name="stipend" required />

        <label htmlFor="description">Description:</label>
        <textarea id="description" name="description" required />

        <label htmlFor="aboutCompany">About Company:</label>
        <textarea id="aboutCompany" name="aboutCompany" required />

        <label htmlFor="numberOfOpenings">Number of Openings:</label>
        <input type="number" id="numberOfOpenings" name="numberOfOpenings" required />

        <label htmlFor="experienceRequired">Experience Required:</label>
        <input type="text" id="experienceRequired" name="experienceRequired" required />

        {/* Add more input fields as needed */}
        
        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default PostInternship;

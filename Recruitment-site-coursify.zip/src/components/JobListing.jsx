// src/components/JobListing.js
import React from 'react';

const JobListing = ({ title, company, location, description }) => {
  return (
    <div className="job-listing">
      <h2>{title}</h2>
      <p>{company}</p>
      <p>{location}</p>
      <p>{description}</p>
      {/* Add apply button or link */}
    </div>
  );
};

export default JobListing;

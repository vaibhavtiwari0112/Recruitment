// src/components/Header.jsx
import React from 'react';
import { Link } from 'react-router-dom';
import { FaUser } from 'react-icons/fa'; 
import logo from '../images/logo.png'; 
import { RiHome4Line, RiInformationLine, RiFileAddLine, RiSearchLine } from 'react-icons/ri'; // Import the required icons from React Icons




const Header = () => {
  return (
    <header className="header">
      <div className='headerNav'>
        <div className="logo">
        <b className='siteNaming'>Finding New Interns</b>
          <img src={logo} alt="Logo" />
        </div>
        
        <ul className="nav-links">
          <li>
            <Link to="/"><RiHome4Line /> Home</Link>
          </li>
          <li>
            <Link to="/about"><RiInformationLine /> About</Link>
          </li>
         
          <li><Link to='/addPost'><RiFileAddLine />Post a Job</Link></li>
        </ul>
        <div className="search-bar">         
          <input type="text" placeholder="Search..." />
          <button><RiSearchLine /></button>
        </div>
      </div>
    </header>
  );
};

export default Header;

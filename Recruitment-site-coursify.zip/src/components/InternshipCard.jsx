// src/components/InternshipCard.js
import React, { useState } from 'react';

const InternshipCard = ({ internship }) => {
  const { title, company, location, duration, stipend, description, image } = internship;

  const [isFormVisible, setIsFormVisible] = useState(false);
  const [isApplied, setIsApplied] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
    resume: null,
  });
var x=0;
  const handleApplyClick = (props) => {
    x=x+1;

    setIsFormVisible(true);
 
    
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setIsFormVisible(false);
    setIsApplied(true);
  };
  const handleCancel = (event) => {
    event.preventDefault();
    setIsFormVisible(false);
    setIsApplied(false);
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setFormData({ ...formData, resume: file });
    }
  };

  return (
    <div className="internship-card">
      <div className="internship-image-container">
        <img src={image} alt={title} className="internship-image" />
      </div>
      <div className="internship-details">
        <h4>{title}</h4>
        <p>{company}</p>
        <p>{location}</p>
        <p>{duration}</p>
        <p className="stipend">Stipend: {stipend}</p>
        <p>{description}</p>

        {isApplied ? (
          <button className="applied-button" disabled>
            Applied
          </button>
        ) : (
          <button className="apply-button" onClick={handleApplyClick}>
            Apply
          </button>
        )}

        {isFormVisible && !isApplied && (
          <form className="apply-form" onSubmit={handleSubmit}>
            <label>
              Name:
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </label>
            <label>
              Email:
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
              />
            </label>
            <label>
              Message:
              <textarea
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                required
              />
            </label>
            <label>
              Resume:
              <input type="file" onChange={handleFileChange} accept=".pdf,.doc,.docx" />
            </label>
            <button type="submit">Submit</button>
            <button type='cancel' onClick={handleCancel}>Cancel</button>
          </form>
        )}
      </div>
    </div>
  );
};

export default InternshipCard;

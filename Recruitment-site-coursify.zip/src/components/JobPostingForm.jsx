// src/components/JobPostingForm.js
import React, { useState } from 'react';

const JobPostingForm = ({ onSubmit }) => {
  const [title, setTitle] = useState('');
  const [company, setCompany] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [managerName, setManagerName] = useState('');
  const [managerEmail, setManagerEmail] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Validate form fields, perform additional checks if required

    // Create a new job post object
    const newJobPost = {
      title,
      company,
      location,
      description,
      manager: {
        name: managerName,
        email: managerEmail,
      },
    };

    // Call the parent component's onSubmit function with the new job post
    onSubmit(newJobPost);

    // Clear form fields after submission
    setTitle('');
    setCompany('');
    setLocation('');
    setDescription('');
    setManagerName('');
    setManagerEmail('');
  };

  return (
    <form onSubmit={handleSubmit}>
      {/* ... (previous fields) ... */}
      <div>
        <label htmlFor="managerName">Manager Name</label>
        <input
          type="text"
          id="managerName"
          value={managerName}
          onChange={(e) => setManagerName(e.target.value)}
          required
        />
      </div>
      <div>
        <label htmlFor="managerEmail">Manager Email</label>
        <input
          type="email"
          id="managerEmail"
          value={managerEmail}
          onChange={(e) => setManagerEmail(e.target.value)}
          required
        />
      </div>
      <button type="submit">Add Post</button>
    </form>
  );
};

export default JobPostingForm;

// src/components/Auth.js
import React from 'react';
import Login from './login';
import Signup from './Signup';

const Auth = () => {
  return (
    <div>
      <Login />
      <Signup />
    </div>
  );
};

export default Auth;

// src/components/AddPost.jsx
import React, { useState } from 'react';
import { AiOutlineClose } from 'react-icons/ai'; // Close icon from React Icons

const AddPost = ({ onClose }) => {
  const [postDetails, setPostDetails] = useState({
    title:'',
    date: '',
    stipend: '',
    description: '',
    company: '',
    openings: '',
    experience: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setPostDetails((prevDetails) => ({
      ...prevDetails,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    console.log('Form submitted:', postDetails);
  };

  return (
    <div className='AddPost'>
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-10">
      <div className="bg-white p-8 rounded-lg max-w-lg w-full">
        {/* <button
          className="absolute top-2 right-2 text-gray-500 hover:text-gray-700"
          onClick={onClose}
        >
          <AiOutlineClose size={20} />
        </button> */}
        <h2 className="text-2xl font-bold mb-4">Post a Job</h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-4 title">
          <label htmlFor="title">Title:</label>
        <input type="text" id="title" name="title" className='mb4title' required />
            <label htmlFor="date">Date:</label>
            <input
              type="date"
              id="date"
              name="date"
              value={postDetails.date}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-4">
            <label htmlFor="stipend">Stipend:</label>
            <input
              type="text"
              id="stipend"
              name="stipend"
              value={postDetails.stipend}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-4">
            <label htmlFor="description">Description:</label>
            <textarea
              id="description"
              name="description"
              rows={10}
              cols={10}
              value={postDetails.description}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-4">
            <label htmlFor="company">Company:</label>
            <input
              type="text"
              id="company"
              name="company"
              value={postDetails.company}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-4">
            <label htmlFor="openings">Number of Openings:</label>
            <input
              type="number"
              id="openings"
              name="openings"
              value={postDetails.openings}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-4">
            <label htmlFor="experience">Experience Required:</label>
            <input
              type="text"
              id="experience"
              name="experience"
              value={postDetails.experience}
              onChange={handleChange}
              required
            />
          </div>
          <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded-md" onClick={handleSubmit}>
            Submit
          </button>
         
        </form>
      </div>
    </div>
    </div>
  );
};

export default AddPost;

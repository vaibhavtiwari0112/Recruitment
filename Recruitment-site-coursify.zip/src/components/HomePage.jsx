// src/components/HomePage.js
import React from 'react';
import internshipData from '../data/internships.json';
import InternshipCard from './InternshipCard';
import { Link } from 'react-router-dom';
import { FaUser } from 'react-icons/fa';
import logo from '../images/logo.png'; 
import { RiSearch2Fill, RiSearchLine } from 'react-icons/ri';


const HomePage = (props) => {
  return (
    <div className="site-content">
      <br></br>
      <div className='loginHome'>
{props.name ? <p>
<b>"Welcome"</b> - {props.name}
<br></br>
<br></br> 
<p><b>Search Here for interested Jobs !!</b></p>
<div className="search-bar2">       
  <input type="text" placeholder="Search..." />
         <button><RiSearchLine /></button>
       </div>
</p>:<>

<b>Login please!!</b><Link className='loginIcon'  to='/login'><FaUser />Login</Link></> }
</div>
<br></br>
<br></br>
      <p className='description'>
        This site helps you to find out or post best internship opportunities in any field.
      </p>
      
      <h2 className='heading-Intro'>Internship Posts</h2>
      <div className="grid">
        {internshipData.map((internship) => (
          <InternshipCard key={internship.id} internship={internship} />
        ))}
      </div>
      <footer>
      <nav>
        <div className="logo">
        <h1 className='site-naming'>Finding New Interns</h1>
          <img src={logo} alt="Logo" />
        </div>
      </nav>
      </footer>
    </div>
  );
};

export default HomePage;

import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
    apiKey: "AIzaSyDuvAMMXzBfC_sJ-XGFIr8R3BSwHrEFpfw",
    authDomain: "assignment-internshala-2cb19.firebaseapp.com",
    projectId: "assignment-internshala-2cb19",
    storageBucket: "assignment-internshala-2cb19.appspot.com",
    messagingSenderId: "30420847911",
    appId: "1:30420847911:web:fd423639977979c606ed02",
    measurementId: "G-RW4TQGKMD9" // This line is optional if you have it in your Firebase configuration
};

const app = initializeApp(firebaseConfig);

const auth = getAuth();

export { app, auth };

import React, { useState , useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import HomePage from './components/HomePage';
import About from './components/About'; // Import the About page
import "./style.css";
import AddPost from './components/AddPost';
import { AiOutlinePlus } from 'react-icons/ai';
import Header from './components/Header';
import PostInternship from './components/PostInternship';
import Login from './components/login'; // Make sure the correct path is imported here
import Signup from './components/Signup';
import InputControl from './components/InputControl';
import { auth } from "./firebase";
import InternshipCard from './components/InternshipCard';
import JobPostingForm from './components/JobPostingForm';


const App = () => {
  const [isAddPostOpen, setIsAddPostOpen] = useState(false);

  const handleAddPostClick = () => {
    setIsAddPostOpen(true);
  };
  const [userName, setUserName] = useState("");

  useEffect(() => {
    auth.onAuthStateChanged((user) => {
      if (user) {
        setUserName(user.displayName);
      } else setUserName("");
    });
  }, []);


  const handleCloseAddPost = () => {
    setIsAddPostOpen(false);
  };

  return (
    <Router>
      <div>
         <Header />
         

         {/* Render the AddPost component when the "Add Post" button is clicked */}
         {isAddPostOpen && <AddPost onClose={handleCloseAddPost} />}

         <Routes>
            <Route path="/" element={<HomePage name={userName}/>} />
            <Route path="/about" element={<About />} /> 
            <Route path="/post-internship" element={<PostInternship name={userName}/>} />
            <Route path="/addPost" element={<AddPost />} />
          
            <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup/>} />
         </Routes>
      </div>
   </Router>
  );
};

export default App;
